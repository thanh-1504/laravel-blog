<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserSocialLink extends Model
{
    use HasFactory;
    protected $fillable = [
        "facebook_url",
        "twitter_url",
        "youtube_url",
        "github_url",
        "linkedin_url",
        "instagram_url",
        'user_id',
    ];

    function user() {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
