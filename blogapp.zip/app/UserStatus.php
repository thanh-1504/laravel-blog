<?php
namespace App;
enum UserStatus: string {
    case Active = "active";
    case InActive = "inactive";
}