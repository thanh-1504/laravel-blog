@extends('back.layout.pages-layout')
@section('content')
    page content
@endsection
