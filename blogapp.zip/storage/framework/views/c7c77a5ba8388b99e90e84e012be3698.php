
<?php $__env->startSection('pageTitle', 'Manage Categories'); ?>
<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.categories');

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1588479480-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener("showParentCategoryModalForm", function(e) {
            $("#pcategory_modal").modal('show')
        })

        window.addEventListener("hideParentCategoryModalForm", function(e) {
            $("#pcategory_modal").modal('hide')
        })

        window.addEventListener("showCategoryModalForm", function(e) {
            $("#category_modal").modal('show')
        })

        window.addEventListener("hideCategoryModalForm", function(e) {
            $("#category_modal").modal('hide')
        })

        $("table tbody#sortable_parent_categories").sortable({
            cursor: "move",
            update: function(event, ui) {
                $(this).children().each(function(index) {
                    if ($(this).attr("data-ordering") != (index + 1)) {
                        $(this).attr("data-ordering", (index + 1)).addClass("updated");
                    }
                });

                let positions = [];
                $(".updated").each(function() {
                    positions.push([$(this).attr("data-index"), $(this).attr("data-ordering")]);
                    $(this).removeClass("updated");
                });

                if (positions.length > 0) {
                    Livewire.dispatch("updateCategoryOrdering", [positions]);
                }
            }
        });

        window.addEventListener('deleteParentCategory', function(event) {
            let id = event.detail[0].id;
            Swal.fire({
                title: 'Thông báo',
                html: 'Bạn có chắc chắn muốn xóa?',
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Hủy',
                confirmButtonText: 'Đồng ý',
                cancelButtonColor: '#d33',
                confirmButtonColor: '#3085d6',
                width: 320,
                allowOutsideClick: false,
                fontSize: '1rem'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.dispatch("deleteParentCategoryAction", [id]);
                    Swal.fire(
                        'Thông báo',
                        'Xóa thành công.',
                        'success'
                    );
                }
            });
        });

        window.addEventListener("deleteCategory", function(event) {
            const id = event.detail[0].id;
            Swal.fire({
                title: 'Thông báo',
                html: 'Bạn có chắc chắn muốn xóa',
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonText: 'Yes, Delete',
                cancelButtonColor: '#d33',
                confirmButtonColor: '#3085d6',
                width: 320,
                allowOutsideClick: false,
                fontSize: '1rem'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.dispatch("deleteCategoryAction", [id]);
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layout.pages-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blogapp\resources\views\back\pages\categories_page.blade.php ENDPATH**/ ?>