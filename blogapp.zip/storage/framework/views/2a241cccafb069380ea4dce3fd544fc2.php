<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Password Reset</title>
    <style>
        @media only screen and (max-width: 600px) {
            .container {
                width: 100% !important;
                padding: 20px !important;
            }

            .btn {
                width: 100% !important;
            }
        }
    </style>
</head>

<body style="margin:0; padding:0; background:#f2f2f2; font-family:Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f2f2f2; padding:40px 0;">
        <tr>
            <td align="center">
                <table class="container" width="600" cellpadding="0" cellspacing="0"
                    style="background:#ffffff; border-radius:8px; overflow:hidden; padding:40px;">

                    <tr>
                        <td align="center" style="padding-bottom:20px;">
                            <h2 style="margin:0; font-size:24px; color:#333;">Reset Your Password</h2>
                        </td>
                    </tr>

                    <tr>
                        <td style="font-size:16px; color:#555; line-height:1.6; padding-bottom:25px;">
                            Hello <?php echo e($user->name); ?><br><br>
                            We received a request to reset your password.
                            Click the button below to set a new password:
                        </td>
                    </tr>

                    <!-- Button -->
                    <tr>
                        <td align="center" style="padding-bottom:30px;">
                            <a href="<?php echo e($actionLink); ?>" class="btn"
                                style="background:#4CAF50; color:#ffffff; padding:14px 24px; 
                                  text-decoration:none; border-radius:5px; font-size:16px; 
                                  display:inline-block;">
                                Reset Password
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td style="font-size:14px; color:#888; line-height:1.5; padding-bottom:20px;">
                            If you did not request a password reset, simply ignore this email.
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td align="center" style="font-size:12px; color:#aaa; padding-top:20px;">
                            <p>&copy;<?php echo e(date('Y')); ?> Blog. All rights reserved.</p>
                        </td>
                    </tr>

                </table>
            </td>
        </tr>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\blogapp\resources\views\email-templates\forgot-template.blade.php ENDPATH**/ ?>