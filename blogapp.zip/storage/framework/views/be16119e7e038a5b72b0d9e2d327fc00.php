<div>
    <div class="user-info-dropdown">
        <div class="dropdown">
            <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                <span class="user-icon">
                    <img style="width: 100%;height: 100%;" src="<?php echo e($user->picture); ?>" alt="" />
                </span>
                <span class="user-name"><?php echo e($user->name); ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                <a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i class="dw dw-home"></i>
                    Trang chủ</a>
                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="dw dw-user1"></i>
                    Hồ sơ</a>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit()"><i
                        class="dw dw-logout"></i> Đăng xuất</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blogapp\resources\views\livewire\admin\top-user-info.blade.php ENDPATH**/ ?>